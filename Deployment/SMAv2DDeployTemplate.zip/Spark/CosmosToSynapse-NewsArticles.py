#!/usr/bin/env python
# coding: utf-8

# # Libraries

# In[1]:


import os
from dateutil.parser import parse
from datetime import datetime, timedelta 
from pyspark.sql.types import StructType, StructField, IntegerType,StringType,DateType, LongType, DecimalType,TimestampType, BooleanType,FloatType
from urllib.parse import urlparse
from azure.cosmos import CosmosClient


# In[2]:


%run "config"


# In[3]:


# Connect to Cosmos
client = CosmosClient(COSMOS_URL, {'masterKey': COSMOS_KEY})
database = client.get_database_client(COSMOS_DATABASE_NAME)
tweet_container_client = database.get_container_client(container=COSMOS_ARTICLE_CONTAINER_NAME)


# In[4]:


%%spark
val dfLastInsertedInDW = spark.read.synapsesql(DB_NAME+".dbo.Articles")
dfLastInsertedInDW.createOrReplaceTempView("dfLastInsertedInDW")


# In[5]:


last_inserted_ts=0
try:
   last_inserted_ts=dfLastInsertedInDW.agg(max("inserted_to_CosmosDB_ts"))
except:
    last_inserted_ts=0
print(last_inserted_ts)


# # News Articles

# In[6]:


query = "SELECT * from items where items.document_type = 'news_article' and items._ts > "  + str(last_inserted_ts)


lstNewsArticles, lstEntities,lstKeyPhrases, lstSentiment, lstTranslations  = ([] for i in range(5))

for article in tweet_container_client.query_items(query,enable_cross_partition_query=True ):
  domain = urlparse(article["url"]).netloc
  publishedAt = parse(article['publishedAt']) + timedelta(hours=3) 
  inserted_to_CosmosDB_datetime = datetime.fromtimestamp(article['_ts'])
  inserted_to_CosmosDB_ts = int(article['_ts'])
  
  title=article['title']
  description=article['description']
  content = article['content']
  lstNewsArticles.append([article['id'], article['topickey'], article['subtopic'],article['source']['name'], article['author'],title, description , article['url'], article['urlToImage'], content, publishedAt, inserted_to_CosmosDB_datetime, inserted_to_CosmosDB_ts,domain, article['lang'], 'News Article'])
  
  if "en" in article['translations_title'].keys() and not article['translations_title']['en'] is None:
    lstTranslations.append([article['id'], 'en','title', article['translations_title']['en'], datetime.now()])
    
  if "ar" in article['translations_title'].keys()  and not article['translations_title']['ar'] is None:
    lstTranslations.append([article['id'], 'ar','title', article['translations_title']['ar'], datetime.now()])
  
  if "en" in article['translations_description'].keys() and not article['translations_description']['en'] is None:
    lstTranslations.append([article['id'], 'en','description', article['translations_description']['en'], datetime.now()])
    
  if "ar" in article['translations_description'].keys() and not article['translations_description']['ar'] is None:
    lstTranslations.append([article['id'], 'ar','description', article['translations_description']['ar'], datetime.now()])
  
  if "en" in article['translations_content'].keys() and not article['translations_content']['en'] is None:
    lstTranslations.append([article['id'], 'en','content', article['translations_content']['en'], datetime.now()])
    
  if "ar" in article['translations_content'].keys() and not article['translations_content']['ar'] is None:
    lstTranslations.append([article['id'], 'ar','content', article['translations_content']['ar'], datetime.now()])

  if "en" in article['key_phrases'].keys():
    for phrase in article['key_phrases']['en']:
      lstKeyPhrases.append([article['id'], phrase, 'English', datetime.now()])
      
  if "ar" in article['key_phrases'].keys():
    for phrase in article['key_phrases']['ar']:
      lstKeyPhrases.append([article['id'], phrase, 'Arabic', datetime.now()])
  
  if 'en' in article['named_entities'].keys():
    for entity in article['named_entities']['en']:
      lstEntities.append([article['id'], entity['category'], entity['subcategory'], entity['text'], 'English', float(entity['confidence_score']), datetime.now() ])

  if 'ar' in article['named_entities'].keys():
    for entity in article['named_entities']['ar']:
      lstEntities.append([article['id'], entity['category'], entity['subcategory'], entity['text'], 'Arabic', float(entity['confidence_score']), datetime.now() ]) 
  
  if "sentiment" in article.keys():
    lstSentiment.append([article['id'], article["sentiment"]["sentiment"], article["sentiment"]["score"], datetime.now()])  


# In[7]:


schema = StructType([StructField("id",StringType(),False),   StructField("Language",StringType(),False),   StructField("Field",StringType(),True),   StructField("Text",StringType(),True),   StructField("created_datetime", TimestampType(), True)])
dfTranslations = spark.createDataFrame(lstTranslations,schema)
dfTranslations.createOrReplaceTempView("dfTranslations")


schema = StructType([StructField("id",StringType(),False),   StructField("KeyPhrase",StringType(),False),   StructField("Language",StringType(),True),   StructField("created_datetime", TimestampType(), True)])
dfKeyPhrases = spark.createDataFrame(lstKeyPhrases,schema)
dfKeyPhrases.createOrReplaceTempView("dfKeyPhrases")

schema = StructType([StructField("id",StringType(),False),   StructField("category",StringType(),False),   StructField("subcategory",StringType(),True),   StructField("value",StringType(),True),   StructField("Language",StringType(),True),   StructField("confidence_score",FloatType(),True),   StructField("created_datetime", TimestampType(), True)])
dfEntities = spark.createDataFrame(lstEntities,schema)
dfEntities.createOrReplaceTempView("dfEntities")

schema = StructType([StructField("id", StringType(), False),  StructField("sentiment", StringType(), True),  StructField("overallscore", FloatType(), True),  StructField("created_datetime", TimestampType(), True)])
dfSentiment = spark.createDataFrame(lstSentiment, schema)
dfSentiment.createOrReplaceTempView("dfSentiment")

schema = StructType([StructField("id",StringType(),False),     StructField("topic",StringType(),True),     StructField("subtopic",StringType(),True),     StructField("sourceName",StringType(),True),     StructField("author",StringType(),True),     StructField("title", StringType(), True),     StructField("description", StringType(), True),     StructField("url", StringType(), True),     StructField("urlToImage",StringType(),True),     StructField("content",StringType(),True),     StructField("publishedAt", TimestampType(), True),     StructField("inserted_to_CosmosDB_datetime",TimestampType(),True),     StructField("inserted_to_CosmosDB_ts", LongType(), True),      StructField("domainname", StringType(), True),     StructField("language", StringType(), True),     StructField("Type", StringType(), True)])
dfNewsArticles = spark.createDataFrame(lstNewsArticles, schema)
dfNewsArticles.createOrReplaceTempView("dfNewsArticles")


# In[8]:


if dfNewsArticles.count() == 0 :
  print("Didn't capture news articles.")
  #dbutils.notebook.exit(0)
else:
  print(str(dfNewsArticles.count()) + " news articles to process.")


# # Synapse Data Ingestion

# In[9]:


%%spark
val scala_dfNewsArticles = spark.sqlContext.sql ("select * from dfNewsArticles")
scala_dfNewsArticles.write.synapsesql(DB_NAME+".stg.[Articles]", Constants.INTERNAL)


# In[10]:

%%spark
val scala_dfEntities = spark.sqlContext.sql ("select * from dfEntities")
scala_dfEntities.write.synapsesql(DB_NAME+".stg.[ArticlesEntities]", Constants.INTERNAL)


# In[11]:


%%spark
val scala_dfSentiment = spark.sqlContext.sql ("select * from dfSentiment")
scala_dfSentiment.write.synapsesql(DB_NAME+".stg.[ArticlesSentiments]", Constants.INTERNAL)


# In[12]:


%%spark
val scala_dfTranslations = spark.sqlContext.sql ("select * from dfTranslations")
scala_dfTranslations.write.synapsesql(DB_NAME+".stg.[ArticlesTranslations]", Constants.INTERNAL)


# In[13]:


%%spark
val scala_dfKeyPhrases = spark.sqlContext.sql ("select * from dfKeyPhrases")
scala_dfKeyPhrases.write.synapsesql(DB_NAME+".stg.[ArticlesKeyPhrases]", Constants.INTERNAL)



