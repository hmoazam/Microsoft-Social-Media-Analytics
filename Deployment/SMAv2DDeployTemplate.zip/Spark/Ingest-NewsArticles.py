#!/usr/bin/env python
# coding: utf-8

# In[7]:


# !pip install newsapi-python
# !pip install tweepy==3.10.0
# !pip install azure-ai-textanalytics==5.1.0
# !pip install langdetect
# !pip install azure-cosmos


# In[2]:


import urllib.parse
import sys, time, json, requests, uuid
from azure.cosmos import CosmosClient
from datetime import datetime, date, timedelta # don't import time here. It messes with the default library
from dateutil.parser import parse
from azure.ai.textanalytics import TextAnalyticsClient
from azure.core.credentials import AzureKeyCredential


# In[3]:


%run "config"


# In[4]:


%run "common"


# In[13]:



COUNTRIES = ["ae", "ar", "at", "au", "be", "bg", "br", "ca", "ch", "cn", "co", "cu", "cz", "de", "eg", "fr", "gb", "gr", "hk", "hu", "id", "ie", "il", "in", "it", "jp", "kr", "lt", "lv", "ma", "mx", "my", "ng", "nl", "no", "nz", "ph", "pl", "pt", "ro", "rs", "ru", "sa", "se", "sg", "si", "sk", "th", "tr", "tw", "ua", "us", "ve", "za"]
LANGUAGE_CODES = {
  "All": "",
  "Afrikaans":"af",
  "Arabic":"ar",
  "Assamese":"as",
  "Bangla":"bn",
  "Bosnian(Latin)":"bs",
  "Bulgarian":"bg",
  "Cantonese(Traditional)":"yue",
  "Catalan":"ca",
  "Chinese Simplified":"zh-Hans",
  "Chinese Traditional":"zh-Hant",
  "Croatian":"hr",
  "Czech":"cs",
  "Dari":"prs",
  "Danish":"da",
  "Dutch":"nl",
  "English":"en",
  "Estonian":"et",
  "Fijian":"fj",
  "Filipino":"fil",
  "Finnish":"fi",
  "French":"fr",
  "German":"de",
  "Greek":"el",
  "Gujarati":"gu",
  "Haitian Creole":"ht",
  "Hebrew":"he",
  "Hindi":"hi",
  "Hmong Daw":"mww",
  "Hungarian":"hu",
  "Icelandic":"is",
  "Indonesian":"id",
  "Irish":"ga",
  "Italian":"it",
  "Japanese":"ja",
  "Kannada":"kn",
  "Kazakh":"kk",
  "Klingon":"tlh-Latn",
  "Klingon(plqaD)":"tlh-Piqd",
  "Korean":"ko",
  "Kurdish(Central)":"ku",
  "Kurdish(Northern)":"kmr",
  "Latvian":"lv",
  "Lithuanian":"lt",
  "Malagasy":"mg",
  "Malay":"ms",
  "Malayalam":"ml",
  "Maltese":"mt",
  "Maori":"mi",
  "Marathi":"mr",
  "Norwegian":"nb",
  "Odia":"or",
  "Pashto":"ps",
  "Persian":"fa",
  "Polish":"pl",
  "Portuguese(Brazil)":"pt-br",
  "Portuguese(Portugal)":"pt-pt",
  "Punjabi":"pa",
  "Queretaro Otomi":"otq",
  "Romanian":"ro",
  "Russian":"ru",
  "Samoan":"sm",
  "Serbian(Cyrillic)":"sr-Cyrl",
  "Serbian(Latin)":"sr-Latn",
  "Slovak":"sk",
  "Slovenian":"sl",
  "Spanish":"es",
  "Swahili":"sw",
  "Swedish":"sv",
  "Tahitian":"ty",
  "Tamil":"ta",
  "Telugu":"te",
  "Thai":"th",
  "Tongan":"to",
  "Turkish":"tr",
  "Ukrainian":"uk",
  "Urdu":"ur",
  "Vietnamese":"vi",
  "Welsh":"cy",
  "Yucatec Maya":"yua"
}


# ### Parameters

# In[14]: Parameters


query = "ooredoo qatar"
topic = "Ooredoo Qatar"
subtopic = ""
languages = "English"
target_languages = "English,Arabic"
from_date = ""
to_date = ""
sort_by = "popularity" # popularity, relevancy, publishedAt
qInTitle = "" #?
page_size = "20"


# In[15]:


# dbutils.widgets.text("topic", "", "Topic")
# dbutils.widgets.text("query", "", "Query")
# dbutils.widgets.multiselect("languages", "All", list(LANGUAGE_CODES.keys()), "Get articles in")
# dbutils.widgets.text("from", "", "From (Date)")
# dbutils.widgets.text("to", "", "To (Date)")
# dbutils.widgets.dropdown("sort_by", "popularity", ["popularity", "relevancy", "publishedAt"], "Sort By")
# dbutils.widgets.text("qInTitle", "", "Search in title")
# dbutils.widgets.text("pageSize", "20", "Articles per Request")
config = {}
#config["topic"] = topic
config["q"] = query
# languages = dbutils.widgets.get("languages")
language_codes = [LANGUAGE_CODES.get(key) for key in languages.split(",") if key != "All"]
config["language"] = ','.join(language_codes)
config["from"] = from_date
config["to"] = to_date
config["sortBy"] = sort_by
config["qInTitle"] = qInTitle
config["pageSize"] = page_size
config["apiKey"] = NEWS_API_KEY
# dbutils.widgets.multiselect("target_languages", "English", list(LANGUAGE_CODES.keys()), "04.Target Languages")
target_languages = [LANGUAGE_CODES.get(lang, "") for lang in target_languages.split(",")]
if "en" not in target_languages:
    target_languages.append("en") # always include english in target languages


# In[16]:


def update_cosmos2(objects, container): # insert tweets/users to cosmos
    for object in objects:
        try:
            response = container.upsert_item(body=object) # use upsert so that insert or update
            print("Inserted data to cosmos")
        except: 
            print("None found")


# In[17]:


# def authenticate_client():
#     ta_credential = AzureKeyCredential(TEXT_ANALYTICS_KEY)
#     text_analytics_client = TextAnalyticsClient(
#             endpoint=TEXT_ANALYTICS_ENDPOINT, 
#             credential=ta_credential)
#     return text_analytics_client

# text_analytics_client = authenticate_client()

# # TODO: Add opinion mining
# def get_sentiment(inp_text):
#     documents = [inp_text]
#     response = text_analytics_client.analyze_sentiment(documents = documents)[0]  
#     overallscore = response.confidence_scores.positive + (0.5*response.confidence_scores.neutral) # check logic of this
#     return response.sentiment, overallscore

# def get_ner(inp_text):
#     try:
#         documents = [inp_text]
#         result = text_analytics_client.recognize_entities(documents = documents)[0]  
#         return [{"text": x.text, "category": x.category, "subcategory": x.subcategory, "length": x.length, "offset": x.offset, "confidence_score": x.confidence_score} for x in result.entities]
#     except Exception as err:
#         print("Encountered exception. {}".format(err))

# def get_key_phrases(inp_text):
#     try:
#         documents = [inp_text]
#         response = text_analytics_client.extract_key_phrases(documents = documents)[0] 
#         if not response.is_error:
#             return response.key_phrases
#         else:
#             print(response.id, response.error)
#     except Exception as err:
#         print("Encountered exception. {}".format(err))
#     return []


# In[18]:


def get_translation(inp_text, from_language, to_languages):
    # Translator setup
    translator_path = "/translate"
    translator_url = TRANSLATOR_ENDPOINT + translator_path
    params = {
    "api-version": "3.0",
    "from": from_language,
    "to": to_languages
    }
    headers = {
    'Ocp-Apim-Subscription-Key': TRANSLATOR_KEY,
    'Ocp-Apim-Subscription-Region': TRANSLATOR_REGION,
    'Content-type': 'application/json',
    'X-ClientTraceId': str(uuid.uuid4())
    }
    # create and send request
    body = [{
    'text': inp_text
    }]
    request = requests.post(translator_url, params=params, headers=headers, json=body)
    response = request.json()

    # only ever one string sent for translation, so only list of length 1
    translations=[]
    try:
        translations = response[0]["translations"]
    except Exception as err:
        print("Encountered an exception. {}".format(err))
    res = {} # dict with language as key and translated text as value e.g. {"ar": "arabic text"}
    for trans in translations:
        res[trans['to']] = trans['text']
    res[from_language] = inp_text # also include the original text and language in translations - overkill?
    return res


# In[19]:


client = CosmosClient(COSMOS_URL, {'masterKey': COSMOS_KEY})
database = client.get_database_client(COSMOS_DATABASE_NAME)

article_container_client = database.get_container_client(container=COSMOS_ARTICLE_CONTAINER_NAME)


# In[20]:


def build_query(config, page=1):
    query = "http://newsapi.org/v2/everything?"
    for k,v in config.items():
        if v is None or v == "":
            continue
        query += f"{k}={v}&"
    query += f"page={page}"
    return query
query = build_query(config)

page = 1
all_articles = []

while True:
    url = build_query(config, page)
    print(f"Getting page {page}...")
    response = requests.get(url).json()
    if response["status"] == "error":
        break
    articles = response.get("articles")
    if not articles:
        break
    for article in articles:
        article["id"] = str(abs(hash(article["url"])))
        search_query = 'select * from items where items.id="{0}"'.format(article["id"])
        items = list(article_container_client.query_items(search_query,enable_cross_partition_query=True))
        if len(items)>0:
            print("Old Article")
        else:
            print("New Article")
            dt2 = datetime.now()
            ts= int(time.mktime(dt2.timetuple()))
            at=dt2.strftime("%m/%d/%Y, %H:%M:%S %Z")
            article['inserted_to_CosmosDB_at'] = at
            article['inserted_to_CosmosDB_ts'] = ts
            article['topickey'] = topic
            article['subtopic'] = subtopic
            article["month_year"] = str(parse(article["publishedAt"]).month) + "_"+str(parse(article["publishedAt"]).year)
            article["document_type"] = "news_article"
            if article["title"] is None:
                article["title"]=article["content"][0:79]
            article["title"]=article["title"][0].upper()+article["title"][1:]

            i=article["title"].find(' ', 80)
            query_language=language_codes[0]

            if i==-1:
                article["title"]=article["title"]
            else:
                if query_language in ['ar','ar-EG']:
                    article["title"]=article["title"][0:i].replace(' ,',',').rstrip(' ').rstrip(',')
                else:
                    article["title"]=article["title"][0:i].replace(' ,',',').rstrip(' ').rstrip(',')+" ..."


            article["translations_title"] = get_translation(article["title"], query_language, target_languages)
            article["translations_description"] = get_translation(article["description"], query_language, target_languages)
            article["translations_content"] = get_translation(article["content"], query_language, target_languages)

            query_language=language_codes[0]
            
            if query_language != "en":
                # then english MUST be in the translations.
                key_phrases_en = get_key_phrases(article["translations_content"]["en"]) 
                # translate them back to the original language    
                key_phrases = [get_translation(x, "en", query_language)[query_language] for x in key_phrases_en] # just print and check
                key_phrases_obj = {"en": key_phrases_en, query_language: key_phrases}
            else:
                key_phrases = get_key_phrases(article["content"])
                key_phrases_obj = {"en": key_phrases}

              # translate all key phrases to all target languages as well
            for lang in target_languages:
                if lang != "en": # since this is already there
                    all_ = []
                    for phrase in key_phrases: # TODO: make more efficient by sending one request but that will need modification to the translate function
                        translated_phrase = get_translation(phrase, "en", lang)[lang]
                        all_.append(translated_phrase)
                    key_phrases_obj[lang] = all_

            article["key_phrases"] = key_phrases_obj
            named_entities = []
            if query_language != "en":
                if article["translations_content"]["en"]!='':
                    named_entities = get_ner(article["translations_content"]["en"])
                    named_entity_obj = {"en": named_entities}
                    org_language_entities = []
                    for ent in named_entities:
                        org_language_ent = ent.copy()
                        org_language_ent["text"] = get_translation(ent["text"], "en", query_language)[query_language] # replace with original language text
                    org_language_entities.append(org_language_ent)

                    named_entity_obj[query_language] = org_language_entities
                else:
                    named_entity_obj = {"en": named_entities}
            else:
                named_entities = get_ner(article["content"]) # list of objects where each object corresponds to an entity
                named_entity_obj = {"en": named_entities}


              # get translation to all target languages for all entities
            for language in target_languages:
                if language != "en":
                    tmp_entities = []
                    for ent in named_entities:
                        tmp_ = ent.copy()
                        tmp_["text"] = get_translation(ent["text"], "en", language)[language]
                        tmp_entities.append(tmp_)
                    named_entity_obj[language] = tmp_entities
            article["named_entities"] = named_entity_obj

              # get sentiment. Not supported for arabic, so do on english. No need to translate back
            if query_language != "en":
                sentiment, sentiment_score = get_sentiment(article["translations_title"]["en"])
            else:
                sentiment, sentiment_score = get_sentiment(article["title"])
            article["sentiment"] = {"sentiment": sentiment, "score": sentiment_score}
            article["lang"]=query_language
            all_articles.append(article)

    page += 1
print("Done! Article: ",str(len(all_articles)))
print("query: ",query)


# In[21]:


update_cosmos2(all_articles, article_container_client) # insert tweets

